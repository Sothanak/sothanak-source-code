# LSAPP - Laravel From Scratch App

This is the source code for the "Laravel From Scratch" Youtube series by Traversy media. It is a website with a blog application. It also includes full authentication and file uploading.

## Version
1.0.0

## Database
The sql dump is in _SQL/lsapp.sql